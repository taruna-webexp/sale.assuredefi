"use client";

import QuotePage from "./quote/page";

export default function Home() {
  return (
    <>
      <QuotePage />
    </>
  );
}
