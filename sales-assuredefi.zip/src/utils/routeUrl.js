export const routesUrl = {
  about: "/about",
  home: "/",
  product: "/product",
  login: "/auth/login",
  signUp: "/auth/signup",
  forgot: "/auth/forgot",
  user: "/user",
};
